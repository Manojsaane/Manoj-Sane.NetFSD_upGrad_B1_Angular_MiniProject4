﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace PatientService.Data
{
    public class PatientDbContextFactory : IDesignTimeDbContextFactory<PatientDbContext>
    {
        public PatientDbContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<PatientDbContext>();

            optionsBuilder.UseSqlServer(
                "Server=host.docker.internal,1433;Database=PatientDB;User Id=sa;Password=Raghu123;TrustServerCertificate=True;"
            );

            return new PatientDbContext(optionsBuilder.Options);
        }
    }
}
